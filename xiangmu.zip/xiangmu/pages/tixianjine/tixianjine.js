const app = getApp();
var util = require('../../utils/fengzhuang.js');
import regeneratorRuntime from '../../regenerator-runtime/runtime.js';
Page({
  data: {

  },
  onLoad: function (options) {
  },
  //申请
  shenqing:function(){
    const e = wx.getStorageSync("e");
    //申请提现
    util.postRequest(app.globalData.url + "withdrawal/add?access-token=" + e.accessToken, { uid: e.loginUser.id, mid: '' })
      .then(function (data) {
        if (data.success && !data.success) {
          console.log('检索失败，' + data.message);
          return;
        }
        console.log('data.data.data', data)

        //将余额修改为0
        let loginUser = e.loginUser;
        loginUser = { ...loginUser, red_envelope: '0.00' }
        wx.setStorageSync('e', { ...e, loginUser: loginUser })
      })
  }
})